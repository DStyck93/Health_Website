<!-- FIXME - Switch DB before pushing -->
<?php
// Test DB
//const DB_SERVER = "localhost";
//const DB_USER = "DStyck";
//const DB_PASS = "k7A85\$RH#T!9%3b@wn9$";
//const DB_NAME = "health_website";

// AWS DB
const DB_SERVER = "health-app.choeccos4euz.us-east-2.rds.amazonaws.com";
const DB_ADMIN = "DStyck";
const DB_ADMIN_PASS= "YTy!32E13#ZEA1&DTWn!";
const DB_NAME = "health_website";

// TODO -- Add user with less permissions
//const DB_USER = "webuser";
//const DB_USER_PASS = "!Y#PUDTao!?fxcU@HLf?"
?>