<!-- TODO - Footer covers text that reaches bottom of page -->

<footer id="footer">
    <p><strong>D.Styx Productions</strong> *trademark pending<br>
        This web application is a work in progress. It is being developed by D.Styck as a capstone project for the Grand
        Canyon University MS Software Development program.
    </p>
</footer>

<!-- Tags opened in other file -->
</body>
</html>

<?php
global $db;
db_disconnect($db);
?>