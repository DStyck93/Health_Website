<?php
global $db;
db_disconnect($db);?>
</body>
</html>