<?php
require_once('../../private/initialize.php');
redirect_to('../../public/index.php');
?>