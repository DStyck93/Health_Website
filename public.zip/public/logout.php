<?php
require_once "../private/initialize.php";

logout();

redirect_to(url_for('index.php'));
?>